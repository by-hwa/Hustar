﻿namespace hw4
{
    partial class HW4
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.n5 = new System.Windows.Forms.Button();
            this.n6 = new System.Windows.Forms.Button();
            this.n7 = new System.Windows.Forms.Button();
            this.n8 = new System.Windows.Forms.Button();
            this.n9 = new System.Windows.Forms.Button();
            this.f_c = new System.Windows.Forms.Button();
            this.n0 = new System.Windows.Forms.Button();
            this.f_add = new System.Windows.Forms.Button();
            this.f_div = new System.Windows.Forms.Button();
            this.f_remain = new System.Windows.Forms.Button();
            this.f_backspace = new System.Windows.Forms.Button();
            this.f_squar = new System.Windows.Forms.Button();
            this.f_sub = new System.Windows.Forms.Button();
            this.f_abs = new System.Windows.Forms.Button();
            this.f_equal = new System.Windows.Forms.Button();
            this.f_dot = new System.Windows.Forms.Button();
            this.f_mul = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.f_subs = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.Location = new System.Drawing.Point(12, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(432, 50);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // n1
            // 
            this.n1.Font = new System.Drawing.Font("굴림", 18F);
            this.n1.Location = new System.Drawing.Point(12, 98);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(67, 52);
            this.n1.TabIndex = 1;
            this.n1.Text = "1";
            this.n1.UseVisualStyleBackColor = true;
            this.n1.Click += new System.EventHandler(this.n1_Click);
            // 
            // n2
            // 
            this.n2.Font = new System.Drawing.Font("굴림", 18F);
            this.n2.Location = new System.Drawing.Point(85, 98);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(67, 52);
            this.n2.TabIndex = 1;
            this.n2.Text = "2";
            this.n2.UseVisualStyleBackColor = true;
            this.n2.Click += new System.EventHandler(this.n2_Click);
            // 
            // n3
            // 
            this.n3.Font = new System.Drawing.Font("굴림", 18F);
            this.n3.Location = new System.Drawing.Point(158, 98);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(67, 52);
            this.n3.TabIndex = 1;
            this.n3.Text = "3";
            this.n3.UseVisualStyleBackColor = true;
            this.n3.Click += new System.EventHandler(this.n3_Click);
            // 
            // n4
            // 
            this.n4.Font = new System.Drawing.Font("굴림", 18F);
            this.n4.Location = new System.Drawing.Point(12, 156);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(67, 52);
            this.n4.TabIndex = 1;
            this.n4.Text = "4";
            this.n4.UseVisualStyleBackColor = true;
            this.n4.Click += new System.EventHandler(this.n4_Click);
            // 
            // n5
            // 
            this.n5.Font = new System.Drawing.Font("굴림", 18F);
            this.n5.Location = new System.Drawing.Point(85, 156);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(67, 52);
            this.n5.TabIndex = 1;
            this.n5.Text = "5";
            this.n5.UseVisualStyleBackColor = true;
            this.n5.Click += new System.EventHandler(this.n5_Click);
            // 
            // n6
            // 
            this.n6.Font = new System.Drawing.Font("굴림", 18F);
            this.n6.Location = new System.Drawing.Point(158, 156);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(67, 52);
            this.n6.TabIndex = 1;
            this.n6.Text = "6";
            this.n6.UseVisualStyleBackColor = true;
            this.n6.Click += new System.EventHandler(this.n6_Click);
            // 
            // n7
            // 
            this.n7.Font = new System.Drawing.Font("굴림", 18F);
            this.n7.Location = new System.Drawing.Point(12, 214);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(67, 52);
            this.n7.TabIndex = 1;
            this.n7.Text = "7";
            this.n7.UseVisualStyleBackColor = true;
            this.n7.Click += new System.EventHandler(this.n7_Click);
            // 
            // n8
            // 
            this.n8.Font = new System.Drawing.Font("굴림", 18F);
            this.n8.Location = new System.Drawing.Point(85, 214);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(67, 52);
            this.n8.TabIndex = 1;
            this.n8.Text = "8";
            this.n8.UseVisualStyleBackColor = true;
            this.n8.Click += new System.EventHandler(this.n8_Click);
            // 
            // n9
            // 
            this.n9.Font = new System.Drawing.Font("굴림", 18F);
            this.n9.Location = new System.Drawing.Point(158, 214);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(67, 52);
            this.n9.TabIndex = 1;
            this.n9.Text = "9";
            this.n9.UseVisualStyleBackColor = true;
            this.n9.Click += new System.EventHandler(this.n9_Click);
            // 
            // f_c
            // 
            this.f_c.Font = new System.Drawing.Font("굴림", 18F);
            this.f_c.Location = new System.Drawing.Point(376, 156);
            this.f_c.Name = "f_c";
            this.f_c.Size = new System.Drawing.Size(67, 52);
            this.f_c.TabIndex = 1;
            this.f_c.Text = "C";
            this.f_c.UseVisualStyleBackColor = true;
            this.f_c.Click += new System.EventHandler(this.f_c_Click);
            // 
            // n0
            // 
            this.n0.Font = new System.Drawing.Font("굴림", 18F);
            this.n0.Location = new System.Drawing.Point(85, 272);
            this.n0.Name = "n0";
            this.n0.Size = new System.Drawing.Size(67, 52);
            this.n0.TabIndex = 1;
            this.n0.Text = "0";
            this.n0.UseVisualStyleBackColor = true;
            this.n0.Click += new System.EventHandler(this.n0_Click);
            // 
            // f_add
            // 
            this.f_add.Font = new System.Drawing.Font("굴림", 18F);
            this.f_add.Location = new System.Drawing.Point(231, 214);
            this.f_add.Name = "f_add";
            this.f_add.Size = new System.Drawing.Size(67, 52);
            this.f_add.TabIndex = 1;
            this.f_add.Text = "+";
            this.f_add.UseVisualStyleBackColor = true;
            this.f_add.Click += new System.EventHandler(this.f_add_Click);
            // 
            // f_div
            // 
            this.f_div.Font = new System.Drawing.Font("굴림", 18F);
            this.f_div.Location = new System.Drawing.Point(231, 156);
            this.f_div.Name = "f_div";
            this.f_div.Size = new System.Drawing.Size(67, 52);
            this.f_div.TabIndex = 1;
            this.f_div.Text = "/";
            this.f_div.UseVisualStyleBackColor = true;
            this.f_div.Click += new System.EventHandler(this.f_div_Click);
            // 
            // f_remain
            // 
            this.f_remain.Font = new System.Drawing.Font("굴림", 18F);
            this.f_remain.Location = new System.Drawing.Point(304, 272);
            this.f_remain.Name = "f_remain";
            this.f_remain.Size = new System.Drawing.Size(67, 52);
            this.f_remain.TabIndex = 1;
            this.f_remain.Text = "%";
            this.f_remain.UseVisualStyleBackColor = true;
            this.f_remain.Click += new System.EventHandler(this.f_remain_Click);
            // 
            // f_backspace
            // 
            this.f_backspace.Font = new System.Drawing.Font("굴림", 18F);
            this.f_backspace.Location = new System.Drawing.Point(377, 98);
            this.f_backspace.Name = "f_backspace";
            this.f_backspace.Size = new System.Drawing.Size(67, 52);
            this.f_backspace.TabIndex = 1;
            this.f_backspace.Text = "<-";
            this.f_backspace.UseVisualStyleBackColor = true;
            this.f_backspace.Click += new System.EventHandler(this.f_backspace_Click);
            // 
            // f_squar
            // 
            this.f_squar.Font = new System.Drawing.Font("굴림", 18F);
            this.f_squar.Location = new System.Drawing.Point(304, 156);
            this.f_squar.Name = "f_squar";
            this.f_squar.Size = new System.Drawing.Size(67, 52);
            this.f_squar.TabIndex = 1;
            this.f_squar.Text = "^";
            this.f_squar.UseVisualStyleBackColor = true;
            this.f_squar.Click += new System.EventHandler(this.f_squar_Click);
            // 
            // f_sub
            // 
            this.f_sub.Font = new System.Drawing.Font("굴림", 18F);
            this.f_sub.Location = new System.Drawing.Point(231, 272);
            this.f_sub.Name = "f_sub";
            this.f_sub.Size = new System.Drawing.Size(67, 52);
            this.f_sub.TabIndex = 1;
            this.f_sub.Text = "-";
            this.f_sub.UseVisualStyleBackColor = true;
            this.f_sub.Click += new System.EventHandler(this.f_sub_Click);
            // 
            // f_abs
            // 
            this.f_abs.Font = new System.Drawing.Font("굴림", 18F);
            this.f_abs.Location = new System.Drawing.Point(304, 98);
            this.f_abs.Name = "f_abs";
            this.f_abs.Size = new System.Drawing.Size(67, 52);
            this.f_abs.TabIndex = 1;
            this.f_abs.Text = "abs";
            this.f_abs.UseVisualStyleBackColor = true;
            this.f_abs.Click += new System.EventHandler(this.f_abs_Click);
            // 
            // f_equal
            // 
            this.f_equal.Font = new System.Drawing.Font("굴림", 18F);
            this.f_equal.Location = new System.Drawing.Point(158, 272);
            this.f_equal.Name = "f_equal";
            this.f_equal.Size = new System.Drawing.Size(67, 52);
            this.f_equal.TabIndex = 1;
            this.f_equal.Text = "=";
            this.f_equal.UseVisualStyleBackColor = true;
            this.f_equal.Click += new System.EventHandler(this.f_equal_Click);
            // 
            // f_dot
            // 
            this.f_dot.Font = new System.Drawing.Font("굴림", 18F);
            this.f_dot.Location = new System.Drawing.Point(304, 214);
            this.f_dot.Name = "f_dot";
            this.f_dot.Size = new System.Drawing.Size(67, 52);
            this.f_dot.TabIndex = 1;
            this.f_dot.Text = ".";
            this.f_dot.UseVisualStyleBackColor = true;
            this.f_dot.Click += new System.EventHandler(this.f_dot_Click);
            // 
            // f_mul
            // 
            this.f_mul.Font = new System.Drawing.Font("굴림", 18F);
            this.f_mul.Location = new System.Drawing.Point(231, 98);
            this.f_mul.Name = "f_mul";
            this.f_mul.Size = new System.Drawing.Size(67, 52);
            this.f_mul.TabIndex = 1;
            this.f_mul.Text = "*";
            this.f_mul.UseVisualStyleBackColor = true;
            this.f_mul.Click += new System.EventHandler(this.f_mul_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("굴림", 12F);
            this.textBox2.Location = new System.Drawing.Point(12, 10);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(432, 26);
            this.textBox2.TabIndex = 0;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // f_subs
            // 
            this.f_subs.Font = new System.Drawing.Font("굴림", 18F);
            this.f_subs.Location = new System.Drawing.Point(12, 272);
            this.f_subs.Name = "f_subs";
            this.f_subs.Size = new System.Drawing.Size(67, 52);
            this.f_subs.TabIndex = 1;
            this.f_subs.Text = "(-)";
            this.f_subs.UseVisualStyleBackColor = true;
            this.f_subs.Click += new System.EventHandler(this.f_subs_Click);
            // 
            // HW4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(455, 337);
            this.Controls.Add(this.f_abs);
            this.Controls.Add(this.f_remain);
            this.Controls.Add(this.f_mul);
            this.Controls.Add(this.f_sub);
            this.Controls.Add(this.f_add);
            this.Controls.Add(this.n0);
            this.Controls.Add(this.f_dot);
            this.Controls.Add(this.f_squar);
            this.Controls.Add(this.f_div);
            this.Controls.Add(this.f_equal);
            this.Controls.Add(this.f_backspace);
            this.Controls.Add(this.f_subs);
            this.Controls.Add(this.f_c);
            this.Controls.Add(this.n9);
            this.Controls.Add(this.n8);
            this.Controls.Add(this.n7);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "HW4";
            this.Text = "HW4";
            this.Load += new System.EventHandler(this.HW4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button n5;
        private System.Windows.Forms.Button n6;
        private System.Windows.Forms.Button n7;
        private System.Windows.Forms.Button n8;
        private System.Windows.Forms.Button n9;
        private System.Windows.Forms.Button f_c;
        private System.Windows.Forms.Button n0;
        private System.Windows.Forms.Button f_add;
        private System.Windows.Forms.Button f_div;
        private System.Windows.Forms.Button f_remain;
        private System.Windows.Forms.Button f_backspace;
        private System.Windows.Forms.Button f_squar;
        private System.Windows.Forms.Button f_sub;
        private System.Windows.Forms.Button f_abs;
        private System.Windows.Forms.Button f_equal;
        private System.Windows.Forms.Button f_dot;
        private System.Windows.Forms.Button f_mul;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button f_subs;
    }
}

